package main

import (
	"github.com/gofiber/fiber/v2"
	"github.com/gofiber/fiber/v2/middleware/cors"
	"github.com/sajalsaraf/Admin-app.git/database"
	"github.com/sajalsaraf/Admin-app.git/routes"
)

func main() {

	database.Connect()
	app := fiber.New() //app is an instance for the4 fibre application

	app.Use(cors.New(cors.Config{
		AllowCredentials: true,
	}))

	routes.Setup(app) //routes package setup function -fibre app as an arguement

	app.Listen(":8000") //fiber application will be accessible from port 8000 on the server
}
